<?php
/**
 * Funzioni e definizioni del tema GoodLactTheme.
 *
 * Questo file contiene tutte le funzioni e le configurazioni specifiche del tuo tema.
 * È qui che puoi registrare menu, sidebar, caricare script e stili, e aggiungere
 * qualsiasi altra funzionalità personalizzata.
 */

/**
 * Configura le funzionalità di base del tema.
 *
 * Questa funzione viene eseguita dopo che il tema è stato caricato.
 * È il posto ideale per registrare funzionalità supportate dal tema come
 * le immagini in evidenza, i menu di navigazione, e il supporto per il titolo dinamico.
 */
function goodlacttheme_setup() {
    // Abilita il supporto per le immagini in evidenza (post thumbnails)
    add_theme_support( 'post-thumbnails' );

    // Registra i menu di navigazione.
    // 'primary-menu' è l'ID interno, 'Menu Principale' è il nome visualizzato nella bacheca di WordPress.
    register_nav_menus( array(
        'primary-menu' => esc_html__( 'Menu Principale', 'goodlacttheme' ),
        // Puoi aggiungere altri menu qui, ad esempio:
        // 'footer-menu'  => esc_html__( 'Menu Footer', 'goodlacttheme' ),
    ) );

    // Abilita il supporto per il titolo dinamico nel tag <title> del <head>.
    // WordPress gestirà automaticamente il titolo della pagina.
    add_theme_support( 'title-tag' );

    // Abilita il supporto per i feed RSS.
    add_theme_support( 'automatic-feed-links' );

    // Abilita il supporto per l'HTML5 per vari elementi, migliorando la validazione.
    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        )
    );

    // Imposta la dimensione predefinita dei contenuti (per le immagini incorporate, ecc.)
    // global $content_width;
    // if ( ! isset( $content_width ) ) {
    //     $content_width = 800; // Larghezza in pixel
    // }
}
add_action( 'after_setup_theme', 'goodlacttheme_setup' );

/**
 * Carica gli script e gli stili del tema.
 *
 * Questa funzione è responsabile di includere il tuo foglio di stile principale (style.css)
 * e qualsiasi script JavaScript personalizzato di cui il tuo tema abbia bisogno.
 */
function goodlacttheme_scripts() {
    // Carica il foglio di stile principale del tema (style.css)
    // get_stylesheet_uri() restituisce l'URL di style.css nella directory del tema.
    wp_enqueue_style( 'goodlacttheme-style', get_stylesheet_uri(), array(), '1.0' );

    // Se hai script JavaScript personalizzati, puoi caricarli qui.
    // Ad esempio, se hai un file chiamato 'custom.js' nella sottocartella 'js' del tuo tema:
    // wp_enqueue_script( 'goodlacttheme-custom-script', get_template_directory_uri() . '/js/custom.js', array('jquery'), '1.0', true );
    // L'array 'jquery' indica che il tuo script dipende da jQuery. 'true' lo carica nel footer.
}
add_action( 'wp_enqueue_scripts', 'goodlacttheme_scripts' );

/**
 * Registra le aree widget (sidebar).
 *
 * Se il tuo tema ha aree dove gli utenti possono trascinare widget (es. una sidebar),
 * le registri qui.
 */
function goodlacttheme_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar Principale', 'goodlacttheme' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Aggiungi widget qui.', 'goodlacttheme' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
    // Puoi registrare altre aree widget qui, ad esempio per il footer.
}
add_action( 'widgets_init', 'goodlacttheme_widgets_init' );

// Aggiungi qui tutte le altre funzioni specifiche del tuo tema.
// Ad esempio, opzioni del tema, filtri personalizzati, shortcode, ecc.
