            </div><!-- #content -->

        <footer id="colophon" class="site-footer">
            <div class="site-info">
                <a href="<?php echo esc_url( __( 'https://wordpress.org/', 'goodlacttheme' ) ); ?>">
                    <?php
                    /* translators: %s: CMS name. */
                    printf( esc_html__( 'Proudly powered by %s', 'goodlacttheme' ), 'WordPress' );
                    ?>
                </a>
                <span class="sep"> | </span>
                <?php
                /* translators: 1: Theme name, 2: Theme author. */
                printf( esc_html__( 'Theme: %1$s by %2$s.', 'goodlacttheme' ), 'GoodLactTheme', '<a href="https://iluminari3d.com/">I Luminari 3D</a>' );
                ?>
            </div><!-- .site-info -->
        </footer><!-- #colophon -->
    </div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
