<?php get_header(); ?>

<main id="primary" class="site-main">

    <?php
    if ( have_posts() ) :

        if ( is_home() && ! is_front_page() ) :
            ?>
            <header>
                <h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
            </header>
            <?php
        endif;

        /* Inizia il Loop di WordPress */
        while ( have_posts() ) :
            the_post();

            /*
             * Include il template specifico per il tipo di post.
             * Questo cerca un file come content-post.php, content-page.php, ecc.
             * Per semplicità, puoi anche inserire il contenuto direttamente qui.
             */
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
                </header><!-- .entry-header -->

                <div class="entry-content">
                    <?php
                    the_content( sprintf(
                        wp_kses(
                            /* translators: %s: Name of current post. Only visible to screen readers */
                            __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'goodlacttheme' ),
                            array(
                                'span' => array(
                                    'class' => array(),
                                ),
                            )
                        ),
                        wp_kses_post( get_the_title() )
                    ) );

                    wp_link_pages( array(
                        'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'goodlacttheme' ),
                        'after'  => '</div>',
                    ) );
                    ?>
                </div><!-- .entry-content -->

                <footer class="entry-footer">
                    <?php // Puoi aggiungere qui meta dati come autore, data, categorie, tag ?>
                </footer><!-- .entry-footer -->
            </article><!-- #post-<?php the_ID(); ?> -->
            <?php

        endwhile;

        the_posts_navigation(); // Navigazione tra gli articoli (Precedente/Successivo)

    else :

        // Se non ci sono post da mostrare
        ?>
        <section class="no-results not-found">
            <header class="page-header">
                <h1 class="page-title"><?php esc_html_e( 'Nessun risultato', 'goodlacttheme' ); ?></h1>
            </header><!-- .page-header -->

            <div class="page-content">
                <p><?php esc_html_e( 'Spiacenti, ma non è stato trovato nulla che corrisponda ai tuoi criteri. Prova a cercare di nuovo.', 'goodlacttheme' ); ?></p>
                <?php
                get_search_form();
                ?>
            </div><!-- .page-content -->
        </section><!-- .no-results -->
        <?php

    endif;
    ?>

</main><!-- #main -->

<?php get_footer(); ?>
